# src/universe.py

COINS = ["ETH", "BTC", "SOL"]
