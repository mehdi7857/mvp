from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Optional

from loguru import logger

from .models import PositionState, Side


@dataclass
class ExecResult:
    ok: bool
    message: str


class DryRunExecutor:
    def __init__(self, auto_flat_cooldown_seconds: int) -> None:
        self.auto_flat_cooldown_seconds = auto_flat_cooldown_seconds
        self._last_close_ts: float = 0.0

    def can_auto_reopen(self) -> bool:
        return (time.time() - self._last_close_ts) >= self.auto_flat_cooldown_seconds

    def open_position(self, coin: str, side: Side) -> ExecResult:
        logger.info(f"DRYRUN OPEN => coin={coin} side={side}")
        return ExecResult(True, "opened_dryrun")

    def close_position(self, state: PositionState) -> ExecResult:
        logger.info(f"DRYRUN CLOSE => coin={state.coin} side={state.side}")
        self._last_close_ts = time.time()
        return ExecResult(True, "closed_dryrun")
