import time
from datetime import datetime, timezone, timedelta

import httpx

from src.exchanges import HyperliquidPublic
from src.logger import setup_logger
from src.strategy import FundingPremiumStrategy, MarketSnapshot, Signal
from src.executor import DryRunExecutor
from src.state import load_position
from src.universe import COINS


NEG_INF = float("-inf")


def now_iso(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")


def safe_float(x):
    try:
        return float(x)
    except Exception:
        return None


def parse_latest(history):
    if not history:
        return None
    return max(history, key=lambda x: int(x.get("time", 0)))


def fetch_latest_snapshot(hl, coin, lookback_hours, log, max_retries=3):
    """
    Safe fetch: handles ReadTimeout / transient network errors.
    Returns MarketSnapshot or None (never raises).
    """
    end_ms = int(time.time() * 1000)
    start_ms = end_ms - int(timedelta(hours=lookback_hours).total_seconds() * 1000)

    last_err = None
    for attempt in range(1, max_retries + 1):
        try:
            hist = hl.funding_history(coin, start_ms=start_ms, end_ms=end_ms)
            latest = parse_latest(hist)
            if not latest:
                return None

            t_ms = int(latest.get("time", 0))
            funding = safe_float(latest.get("fundingRate"))
            premium = safe_float(latest.get("premium"))

            if funding is None or premium is None:
                return None

            return MarketSnapshot(
                coin=coin,
                funding_rate=funding,
                premium=premium,
                timestamp_ms=t_ms,
            )

        except (httpx.ReadTimeout, httpx.ConnectTimeout, httpx.ConnectError, httpx.RemoteProtocolError) as e:
            last_err = e
            sleep_s = 0.5 * (2 ** (attempt - 1))  # 0.5, 1.0, 2.0
            log.warning(
                "API transient error | coin=%s attempt=%d/%d err=%s | sleeping=%.1fs"
                % (coin, attempt, max_retries, type(e).__name__, sleep_s)
            )
            time.sleep(sleep_s)
            continue
        except httpx.HTTPStatusError as e:
            last_err = e
            log.warning("API HTTPStatusError | coin=%s err=%s" % (coin, str(e)))
            return None
        except Exception as e:
            last_err = e
            log.warning("API unexpected error | coin=%s err=%s" % (coin, repr(e)))
            return None

    log.warning(
        "API failed after retries | coin=%s last_err=%s"
        % (coin, type(last_err).__name__ if last_err else "None")
    )
    return None


# ---------- Scoring (gated) ----------

def score_short(snap) -> float:
    # SHORT_PERP_LONG_SPOT wants premium > 0 AND funding > 0
    if snap.premium <= 0 or snap.funding_rate <= 0:
        return NEG_INF
    return snap.premium + snap.funding_rate


def score_long(snap) -> float:
    # LONG_PERP_SHORT_SPOT wants premium < 0 AND funding < 0
    if snap.premium >= 0 or snap.funding_rate >= 0:
        return NEG_INF
    return (-snap.premium) + (-snap.funding_rate)


def fmt_score(x: float) -> str:
    if x == NEG_INF:
        return "N/A"
    return f"{x:.6f}"


def best_opportunity(snaps):
    best_snap = None
    best_side = None
    best_score_val = NEG_INF

    for s in snaps:
        sh = score_short(s)
        if sh > best_score_val:
            best_score_val = sh
            best_snap = s
            best_side = "SHORT_PERP_LONG_SPOT"

        lg = score_long(s)
        if lg > best_score_val:
            best_score_val = lg
            best_snap = s
            best_side = "LONG_PERP_SHORT_SPOT"

    return best_snap, best_side, best_score_val


def current_score_for_side(snap, side) -> float:
    if side == "SHORT_PERP_LONG_SPOT":
        return score_short(snap)
    if side == "LONG_PERP_SHORT_SPOT":
        return score_long(snap)
    return NEG_INF


# ---------- Rotate helpers (ratio + abs) ----------

def should_rotate(
    best_snap,
    best_side,
    best_score,
    pos_snap,
    pos_side,
    rotate_factor,
    rotate_min_abs_best,
    rotate_min_abs_delta,
):
    if best_snap is None or best_side is None:
        return False
    if best_score == NEG_INF:
        return False

    # no rotate if same coin+side
    if best_snap.coin == pos_snap.coin and best_side == pos_side:
        return False

    # best must be meaningfully large
    if best_score < rotate_min_abs_best:
        return False

    cur_score = current_score_for_side(pos_snap, pos_side)
    cur_base = cur_score if cur_score != NEG_INF else 1e-12

    # ratio AND abs delta
    if best_score >= rotate_factor * max(1e-12, cur_base):
        if (best_score - cur_base) >= rotate_min_abs_delta:
            return True

    return False


def main():
    log = setup_logger()

    POLL_SEC = 10
    LOOKBACK_HOURS = 24

    # ROTATE calibration (ratio + absolute)
    ROTATE_FACTOR = 1.30
    ROTATE_MIN_ABS_BEST = 0.00020
    ROTATE_MIN_ABS_DELTA = 0.00010
    ROTATE_COOLDOWN_SEC = 300  # 5 min

    # AUTO-FLAT safety to prevent immediate churn after a close
    AUTO_REENTER_COOLDOWN_SEC = 60  # 1 min

    strat = FundingPremiumStrategy(
        prem_entry=0.00040,
        fund_entry=0.00001,
        prem_exit=0.00020,
        fund_exit=0.00000,
    )

    executor = DryRunExecutor(notional_usd=1000.0)

    restored = load_position()
    if restored is not None:
        executor.position = restored
        log.info(
            "RESTORED position | coin=%s side=%s entry_premium=%.6f funding_pnl=$%.2f"
            % (restored.coin, restored.side, restored.entry_premium, restored.funding_pnl_usd)
        )

    hl = HyperliquidPublic()

    log.info(
        "Starting MULTI-COIN DRY-RUN bot (bi-directional, gated, ROTATE calibrated, AUTO-FLAT) | coins=%s poll=%ss lookback=%sh notional=$%.2f"
        % (COINS, POLL_SEC, LOOKBACK_HOURS, executor.notional_usd)
    )

    last_seen_time_ms = {c: None for c in COINS}
    LEADERBOARD_SEC = 30
    last_board = time.time()

    last_rotate_ts = 0.0
    last_reenter_ts = 0.0

    try:
        while True:
            # ---- fetch snapshots (safe) ----
            snaps = []
            for coin in COINS:
                s = fetch_latest_snapshot(hl, coin, LOOKBACK_HOURS, log, max_retries=3)
                if s is not None:
                    snaps.append(s)

            if not snaps:
                log.warning("No snapshots fetched this round; sleeping...")
                time.sleep(POLL_SEC)
                continue

            best_snap, best_side, best_score_val = best_opportunity(snaps)

            # helper: try open best if flat
            def try_open_best(reason_prefix: str):
                nonlocal last_reenter_ts
                if (time.time() - last_reenter_ts) < AUTO_REENTER_COOLDOWN_SEC:
                    return
                if best_snap is None or best_score_val == NEG_INF:
                    return

                sig_open = strat.decide(best_snap, None)
                if sig_open.action == "OPEN":
                    st = executor.on_signal(best_snap, sig_open)
                    log.info(
                        "[%s] %s | AUTO_OPEN BEST=%s funding=%.6f premium=%.6f score=%s -> OPEN (%s) | %s"
                        % (
                            now_iso(best_snap.timestamp_ms),
                            reason_prefix,
                            best_snap.coin,
                            best_snap.funding_rate,
                            best_snap.premium,
                            fmt_score(best_score_val),
                            sig_open.side,
                            st,
                        )
                    )
                    last_reenter_ts = time.time()

            # ---------------- IN POSITION ----------------
            if executor.current_side() is not None and executor.position is not None:
                pos_coin = executor.position.coin
                pos_side = executor.position.side
                pos_snap = next((s for s in snaps if s.coin == pos_coin), None)

                # manage current position only on a new timestamp for that coin
                if pos_snap is not None and last_seen_time_ms.get(pos_coin) != pos_snap.timestamp_ms:
                    last_seen_time_ms[pos_coin] = pos_snap.timestamp_ms

                    sig = strat.decide(pos_snap, executor.current_side())
                    status = executor.on_signal(pos_snap, sig)

                    log.info(
                        "[%s] %s funding=%.6f premium=%.6f -> %s | %s"
                        % (
                            now_iso(pos_snap.timestamp_ms),
                            pos_coin,
                            pos_snap.funding_rate,
                            pos_snap.premium,
                            sig.action,
                            status,
                        )
                    )

                    # ---- AUTO-FLAT SAFETY ----
                    # If strategy closed us and we're now flat, immediately try to open best valid edge.
                    if sig.action == "CLOSE" and executor.current_side() is None:
                        try_open_best("AUTO-FLAT")

                # ROTATE check (cooldown) - only if still in position
                if executor.current_side() is not None and executor.position is not None:
                    pos_coin = executor.position.coin
                    pos_side = executor.position.side
                    pos_snap = next((s for s in snaps if s.coin == pos_coin), None)

                    if pos_snap is not None and (time.time() - last_rotate_ts) >= ROTATE_COOLDOWN_SEC:
                        if should_rotate(
                            best_snap,
                            best_side,
                            best_score_val,
                            pos_snap,
                            pos_side,
                            ROTATE_FACTOR,
                            ROTATE_MIN_ABS_BEST,
                            ROTATE_MIN_ABS_DELTA,
                        ):
                            open_sig = strat.decide(best_snap, None)
                            if open_sig.action == "OPEN":
                                close_sig = Signal(
                                    action="CLOSE",
                                    reason=( 
                                        "ROTATE: close %s/%s -> open %s/%s (best=%s cur=%s)"
                                        % (
                                            pos_coin,
                                            pos_side,
                                            best_snap.coin,
                                            open_sig.side,
                                            fmt_score(best_score_val),
                                            fmt_score(current_score_for_side(pos_snap, pos_side)),
                                        )
                                    ),
                                    coin=pos_coin,
                                    side=None,
                                )
                                close_status = executor.on_signal(pos_snap, close_sig)
                                log.info(
                                    "[%s] ROTATE_CLOSE | %s funding=%.6f premium=%.6f -> CLOSE | %s"
                                    % (
                                        now_iso(pos_snap.timestamp_ms),
                                        pos_coin,
                                        pos_snap.funding_rate,
                                        pos_snap.premium,
                                        close_status,
                                    )
                                )

                                open_status = executor.on_signal(best_snap, open_sig)
                                log.info(
                                    "[%s] ROTATE_OPEN | %s funding=%.6f premium=%.6f -> OPEN (%s) | %s"
                                    % (
                                        now_iso(best_snap.timestamp_ms),
                                        best_snap.coin,
                                        best_snap.funding_rate,
                                        best_snap.premium,
                                        open_sig.side,
                                        open_status,
                                    )
                                )

                                last_rotate_ts = time.time()
                                last_reenter_ts = time.time()  # prevent immediate double-open elsewhere
                            else:
                                log.info(
                                    "ROTATE_SKIPPED | best=%s/%s score=%s but strategy says %s (%s)"
                                    % (
                                        best_snap.coin if best_snap else "-",
                                        best_side if best_side else "-",
                                        fmt_score(best_score_val),
                                        open_sig.action,
                                        open_sig.reason,
                                    )
                                )

            # ---------------- FLAT ----------------
            else:
                # When flat, open only on a new timestamp for the best coin
                if best_snap is not None and best_score_val != NEG_INF:
                    c = best_snap.coin
                    if last_seen_time_ms.get(c) != best_snap.timestamp_ms:
                        last_seen_time_ms[c] = best_snap.timestamp_ms
                        sig = strat.decide(best_snap, None)
                        status = executor.on_signal(best_snap, sig)

                        log.info(
                            "[%s] BEST=%s best_side=%s funding=%.6f premium=%.6f score=%s -> %s | %s"
                            % (
                                now_iso(best_snap.timestamp_ms),
                                best_snap.coin,
                                best_side,
                                best_snap.funding_rate,
                                best_snap.premium,
                                fmt_score(best_score_val),
                                sig.action,
                                status,
                            )
                        )

            # ---------------- LEADERBOARD ----------------
            if time.time() - last_board >= LEADERBOARD_SEC:
                last_board = time.time()

                parts = []
                for s in snaps:
                    parts.append(
                        "%s short=%s long=%s (prem=%.6f fund=%.6f)"
                        % (
                            s.coin,
                            fmt_score(score_short(s)),
                            fmt_score(score_long(s)),
                            s.premium,
                            s.funding_rate,
                        )
                    )

                side = executor.current_side() or "FLAT"
                pos_coin = executor.position.coin if executor.position else "-"
                best_coin = best_snap.coin if best_snap is not None else "-"
                best_side_out = best_side if best_side is not None else "-"
                log.info(
                    "LEADERBOARD | pos=%s/%s | BEST=%s/%s score=%s | %s"
                    % (pos_coin, side, best_coin, best_side_out, fmt_score(best_score_val), " | ".join(parts))
                )

            time.sleep(POLL_SEC)

    except KeyboardInterrupt:
        log.info("Stopped by user")
    finally:
        hl.close()


if __name__ == "__main__":
    main()
