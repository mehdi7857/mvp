from __future__ import annotations

import json
import os
from dataclasses import asdict
from typing import Optional

from loguru import logger

from .models import PositionState


def _ensure_dir(path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)


def load_state(path: str) -> Optional[PositionState]:
    if not os.path.exists(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        st = PositionState(**raw)
        return st
    except Exception as e:
        logger.error(f"Failed to load state from {path}: {type(e).__name__}: {e}")
        return None


def save_state(path: str, state: Optional[PositionState]) -> None:
    _ensure_dir(path)
    try:
        if state is None:
            # Write an explicit null state
            with open(path, "w", encoding="utf-8") as f:
                json.dump(None, f, ensure_ascii=False, indent=2)
            return

        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(state), f, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Failed to save state to {path}: {type(e).__name__}: {e}")
