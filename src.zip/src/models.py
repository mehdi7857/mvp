from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional


Side = Literal["SHORT_PERP_LONG_SPOT", "LONG_PERP_SHORT_SPOT"]
Action = Literal["OPEN", "HOLD", "CLOSE"]


@dataclass(frozen=True)
class Snapshot:
    coin: str
    fundingRate: Optional[float]
    premium: Optional[float]
    time: int  # epoch ms (as Hyperliquid returns)


@dataclass
class PositionState:
    coin: str
    side: Side
    is_open: bool
    opened_at_ms: int
